# Batloung Fruits Distribution Management System

Stock, supplier, street-vendor and order management for Batloung Fruits in
Maseru, Lesotho. Staff sign in with role-based access (Administrator or
Sales), record supplier purchases by South African province, register
vendors, and move orders from Pending through to Completed.

## Built with

- TanStack Start (React + server functions)
- TypeScript
- Tailwind CSS
- MySQL

## Development

You need Node.js and npm, plus a local MySQL server running.

```sh
# 1. Create the database, tables and sample data
mysql -u root -p < db/schema.sql

# 2. Set your DB credentials
cp .env.example .env
# then edit .env with your real MySQL password

# 3. Install and run
npm install
npm run dev
```

The first six accounts created on the sign-up page become Administrators;
every account after that is a Sales user. See `docs/SYSTEM-DOCUMENTATION.md`
for the full feature and business-rule description.

## Vendor GPS and nearest vendor

Each vendor can have GPS coordinates and a location name. Administrators can search a place or click/drag a pin on a free OpenStreetMap map, type coordinates, press "Use this device's GPS" (which also fills in the place name), or share a device's live position as a vendor. Sales staff can open the Street vendors page (read only) and press "Find nearest vendor" to see the closest active vendor and straight-line distances from their own GPS. No map or API key is needed.

If your database was created before this feature, run `db/upgrade-v3.sql` once (it adds the latitude, longitude, accuracy and last-updated columns to `street_vendors`).
