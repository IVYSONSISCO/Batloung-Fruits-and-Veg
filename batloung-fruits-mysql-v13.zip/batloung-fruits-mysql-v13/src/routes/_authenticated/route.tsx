import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";
import { getCurrentUser } from "@/lib/api/auth.functions";
import { getStoredToken, setStoredToken } from "@/hooks/useAuth";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    const token = getStoredToken();
    if (!token) throw redirect({ to: "/auth" });
    try {
      const user = await getCurrentUser({ data: { token } });
      return { user };
    } catch {
      setStoredToken(null);
      throw redirect({ to: "/auth" });
    }
  },
  component: () => <Outlet />,
});
