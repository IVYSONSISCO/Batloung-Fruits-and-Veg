import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Pencil, Plus } from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "@/components/management/app-shell";
import { EmptyState, ErrorState, LoadingRows, Metric, PageHeader, SearchBox } from "@/components/management/page";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useCurrentStaff } from "@/hooks/useAuth";
import { createFruit, createProduct, fetchBoxSizes, fetchFruits, fetchProducts, updateProduct, type Fruit, type Product } from "@/lib/api/catalogue.functions";
import { errorMessage, money } from "@/lib/management";

const meta = [
  { title: "Fruits & Products | Batloung Fruits" }, { name: "description", content: "Manage fruit varieties, box sizes, prices and stock." },
  { property: "og:title", content: "Fruits & Products | Batloung Fruits" }, { property: "og:description", content: "Manage the Batloung Fruits product catalogue." },
  { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
];
export const Route = createFileRoute("/_authenticated/products")({ head: () => ({ meta }), component: ProductsPage });

function ProductsPage() {
  const staff = useCurrentStaff();
  const client = useQueryClient();
  const [search, setSearch] = useState("");
  const [fruitOpen, setFruitOpen] = useState(false);
  const [productOpen, setProductOpen] = useState(false);
  const [editing, setEditing] = useState<Product | null>(null);
  const query = useQuery({ queryKey: ["catalogue"], queryFn: async () => { const [products, fruits, sizes] = await Promise.all([fetchProducts(), fetchFruits(), fetchBoxSizes()]); return { products, fruits, sizes }; }});
  const products = useMemo(() => (query.data?.products ?? []).filter((item) => `${item.fruits?.name} ${item.box_sizes?.name}`.toLowerCase().includes(search.toLowerCase())), [query.data, search]);
  const stock = (query.data?.products ?? []).reduce((sum, item) => sum + item.stock_quantity, 0);
  return <AppShell>
    <PageHeader title="Fruits & products" description="Catalogue, selling prices and live box stock." action={staff.isAdmin ? <div className="flex gap-2"><Button variant="outline" onClick={() => setFruitOpen(true)}><Plus className="size-4" /> Fruit</Button><Button onClick={() => { setEditing(null); setProductOpen(true); }}><Plus className="size-4" /> Product</Button></div> : undefined} />
    <div className="grid gap-4 sm:grid-cols-3"><Metric label="Fruit varieties" value={query.data?.fruits.length ?? "—"} /><Metric label="Products" value={query.data?.products.length ?? "—"} /><Metric label="Boxes in stock" value={stock} /></div>
    <div className="surface-card overflow-hidden"><div className="flex items-center justify-between gap-4 border-b p-4"><SearchBox value={search} onChange={setSearch} placeholder="Search fruit or box size" /><Badge variant="secondary">{products.length} products</Badge></div>
      {query.isLoading ? <LoadingRows /> : query.error ? <ErrorState message={errorMessage(query.error)} /> : products.length === 0 ? <EmptyState title="No products found" description="Adjust your search or add a product." /> : <Table><TableHeader><TableRow><TableHead>Fruit</TableHead><TableHead>Box size</TableHead><TableHead>Units</TableHead><TableHead>Price</TableHead><TableHead>Stock</TableHead><TableHead>Status</TableHead>{staff.isAdmin && <TableHead className="w-12" />}</TableRow></TableHeader><TableBody>{products.map((item) => <TableRow key={item.id}><TableCell className="font-medium">{item.fruits?.name}</TableCell><TableCell>{item.box_sizes?.name}</TableCell><TableCell>{item.box_sizes?.units_per_box}</TableCell><TableCell>{money(item.unit_price)}</TableCell><TableCell><span className={item.stock_quantity < 10 ? "font-semibold text-destructive" : "font-semibold"}>{item.stock_quantity}</span></TableCell><TableCell><Badge variant={item.is_active ? "default" : "outline"}>{item.is_active ? "Active" : "Inactive"}</Badge></TableCell>{staff.isAdmin && <TableCell><Button size="icon" variant="ghost" title="Edit product" onClick={() => { setEditing(item); setProductOpen(true); }}><Pencil className="size-4" /><span className="sr-only">Edit</span></Button></TableCell>}</TableRow>)}</TableBody></Table>}
    </div>
    <FruitDialog open={fruitOpen} onOpenChange={setFruitOpen} onSaved={() => client.invalidateQueries({ queryKey: ["catalogue"] })} />
    {query.data && <ProductDialog open={productOpen} onOpenChange={setProductOpen} product={editing} fruits={query.data.fruits} sizes={query.data.sizes} onSaved={() => client.invalidateQueries({ queryKey: ["catalogue"] })} />}
  </AppShell>;
}

function FruitDialog({ open, onOpenChange, onSaved }: { open: boolean; onOpenChange: (open: boolean) => void; onSaved: () => void }) {
  const staff = useCurrentStaff(); const [name, setName] = useState(""); const [description, setDescription] = useState(""); const [busy, setBusy] = useState(false);
  async function save() { if (!name.trim()) return void toast.error("Fruit name is required"); setBusy(true); try { await createFruit({ data: { token: staff.token ?? "", name: name.trim(), description: description.trim() } }); } catch (err) { setBusy(false); return void toast.error(errorMessage(err)); } setBusy(false); toast.success("Fruit added"); setName(""); setDescription(""); onOpenChange(false); onSaved(); }
  return <Dialog open={open} onOpenChange={onOpenChange}><DialogContent><DialogHeader><DialogTitle>Add fruit</DialogTitle><DialogDescription>Create a fruit variety for the product catalogue.</DialogDescription></DialogHeader><div className="space-y-4"><Field label="Fruit name"><Input value={name} onChange={(e) => setName(e.target.value)} /></Field><Field label="Description"><Input value={description} onChange={(e) => setDescription(e.target.value)} /></Field></div><DialogFooter><Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button><Button onClick={save} disabled={busy}>Save fruit</Button></DialogFooter></DialogContent></Dialog>;
}

function ProductDialog({ open, onOpenChange, product, fruits, sizes, onSaved }: { open: boolean; onOpenChange: (open: boolean) => void; product: Product | null; fruits: Fruit[]; sizes: { id: string; name: string }[]; onSaved: () => void }) {
  const staff = useCurrentStaff(); const [fruitId, setFruitId] = useState(""); const [sizeId, setSizeId] = useState(""); const [price, setPrice] = useState(""); const [active, setActive] = useState(true); const [busy, setBusy] = useState(false);
  const shownFruit = fruitId || product?.fruit_id || ""; const shownSize = sizeId || product?.box_size_id || ""; const shownPrice = price || (product ? String(product.unit_price) : "");
  async function save() { const unitPrice = Number(shownPrice); if (!shownFruit || !shownSize || unitPrice <= 0) return void toast.error("Choose a fruit and box size, then enter a valid price"); setBusy(true); try { if (product) await updateProduct({ data: { token: staff.token ?? "", id: product.id, fruitId: shownFruit, boxSizeId: shownSize, unitPrice, isActive: active } }); else await createProduct({ data: { token: staff.token ?? "", fruitId: shownFruit, boxSizeId: shownSize, unitPrice } }); } catch (err) { setBusy(false); return void toast.error(errorMessage(err)); } setBusy(false); toast.success(product ? "Product updated" : "Product added"); setFruitId(""); setSizeId(""); setPrice(""); onOpenChange(false); onSaved(); }
  return <Dialog open={open} onOpenChange={onOpenChange}><DialogContent><DialogHeader><DialogTitle>{product ? "Edit product" : "Add product"}</DialogTitle><DialogDescription>Set the fruit, box size and selling price.</DialogDescription></DialogHeader><div className="grid gap-4 sm:grid-cols-2"><Field label="Fruit"><Select value={shownFruit} onValueChange={setFruitId}><SelectTrigger><SelectValue placeholder="Choose fruit" /></SelectTrigger><SelectContent>{fruits.filter((f) => f.is_active).map((f) => <SelectItem key={f.id} value={f.id}>{f.name}</SelectItem>)}</SelectContent></Select></Field><Field label="Box size"><Select value={shownSize} onValueChange={setSizeId}><SelectTrigger><SelectValue placeholder="Choose size" /></SelectTrigger><SelectContent>{sizes.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent></Select></Field><Field label="Selling price (M)"><Input type="number" min="0.01" step="0.01" value={shownPrice} onChange={(e) => setPrice(e.target.value)} /></Field>{product && <div className="flex items-end gap-3 pb-2"><Switch checked={active} onCheckedChange={setActive} /><Label>Available for sale</Label></div>}</div><DialogFooter><Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button><Button onClick={save} disabled={busy}>Save product</Button></DialogFooter></DialogContent></Dialog>;
}
function Field({ label, children }: { label: string; children: React.ReactNode }) { return <div className="space-y-1.5"><Label>{label}</Label>{children}</div>; }