import { useEffect, useMemo, useRef, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Crosshair, Eye, MapPin, Phone, Store, Pencil, Plus, Radio, Square, ListFilter, X } from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "@/components/management/app-shell";
import { EmptyState, ErrorState, LoadingRows, PageHeader, SearchBox } from "@/components/management/page";
import { StatusBadge } from "@/components/management/status-badge";
import { PlaceSearch, VendorMap, reverseGeocode } from "@/components/management/vendor-map";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { updateVendorLocation, createVendor, fetchVendors, updateVendor, type Vendor } from "@/lib/api/vendors.functions";
import { errorMessage, shortDate } from "@/lib/management";
import { distanceKm, hasCoordinates, nearestActiveVendor, radiusInMeters, filterVendorsByRadius } from "@/lib/vendor-distance";
import { TravelModeSelector, VendorTravel } from "@/components/management/vendor-travel";
import type { TravelMode } from "@/lib/vendor-distance";
import type { Coordinates, DistanceUnit } from "@/lib/vendor-distance";
import { useCurrentStaff } from "@/hooks/useAuth";
import { VendorFilterFields } from "@/components/management/vendor-filters";
import { canUseVendorFilters, emptyVendorFilters, filterVendorDetails, sortVendorDetails } from "@/lib/vendor-filters";

const meta = [{ title: "Street Vendors & Nearest Vendor | Batloung Fruits" }, { name: "description", content: "View Maseru vendor locations and find the nearest active vendor to your GPS location." }, { property: "og:title", content: "Street Vendors & Nearest Vendor | Batloung Fruits" }, { property: "og:description", content: "Vendor locations, straight-line distances and nearest active vendor suggestions for Batloung Fruits sales staff." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }];
export const Route = createFileRoute("/_authenticated/vendors")({ head: () => ({ meta }), component: VendorsPage });

const MIN_SEND_MS = 15_000;

function ago(iso: string | null) {
  if (!iso) return "never";
  const s = Math.round((Date.now() - new Date(iso).getTime()) / 1000);
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.round(s / 60)}m ago`;
  if (s < 86400) return `${Math.round(s / 3600)}h ago`;
  return shortDate(iso);
}

function VendorsPage() {
  const client = useQueryClient();
  const staff = useCurrentStaff();
  const isAdmin = staff.isAdmin;
  const canFilter = canUseVendorFilters(isAdmin, staff.role);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [filters, setFilters] = useState(emptyVendorFilters);
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Vendor | null>(null);
  const [travelMode, setTravelMode] = useState<TravelMode>("walking");
  const [viewing, setViewing] = useState<Vendor | null>(null);
  const [trackingId, setTrackingId] = useState<string | null>(null);
  const watchRef = useRef<number | null>(null);
  const lastSent = useRef(0);
  const [myLocation, setMyLocation] = useState<(Coordinates & { accuracy: number; capturedAt: string }) | null>(null);
  const [findingNearby, setFindingNearby] = useState(false);
  const [locationError, setLocationError] = useState<string | null>(null);
  const [radius, setRadius] = useState("2");
  const [radiusUnit, setRadiusUnit] = useState<DistanceUnit>("m");
  const [appliedRadius, setAppliedRadius] = useState<number | null>(null);

  function findNearby() {
    if (!("geolocation" in navigator)) {
      setLocationError("This device does not support GPS location.");
      return;
    }
    setFindingNearby(true);
    setLocationError(null);
    navigator.geolocation.getCurrentPosition((position) => {
      setMyLocation({ latitude: position.coords.latitude, longitude: position.coords.longitude, accuracy: position.coords.accuracy, capturedAt: new Date().toISOString() });
      setFindingNearby(false);
    }, (error) => {
      setFindingNearby(false);
      setLocationError(error.code === error.PERMISSION_DENIED ? "Location permission denied. Allow location access in your browser and try again." : error.code === error.TIMEOUT ? "GPS timed out. Try again where your device can get a signal." : "Your location is unavailable. Check that device location is switched on and try again.");
    }, { enableHighAccuracy: true, maximumAge: 0, timeout: 20_000 });
  }

  const query = useQuery({
    queryKey: ["vendors"],
    refetchInterval: 15_000,
    queryFn: () => fetchVendors(),
  });

  useEffect(() => () => { if (watchRef.current != null) navigator.geolocation.clearWatch(watchRef.current); }, []);

  function stopTracking() {
    if (watchRef.current != null) navigator.geolocation.clearWatch(watchRef.current);
    watchRef.current = null;
    setTrackingId(null);
    toast.info("Live location sharing stopped");
  }

  function startTracking(v: Vendor) {
    if (!isAdmin) return;
    if (!("geolocation" in navigator)) return void toast.error("This device does not support GPS location");
    if (watchRef.current != null) navigator.geolocation.clearWatch(watchRef.current);
    lastSent.current = 0;
    setTrackingId(v.id);
    watchRef.current = navigator.geolocation.watchPosition(
      async (pos) => {
        if (Date.now() - lastSent.current < MIN_SEND_MS) return;
        lastSent.current = Date.now();
        try {
          await updateVendorLocation({ data: { token: staff.token ?? "", id: v.id, latitude: pos.coords.latitude, longitude: pos.coords.longitude, accuracy: pos.coords.accuracy } });
          client.invalidateQueries({ queryKey: ["vendors"] });
        } catch (err) {
          toast.error(errorMessage(err));
        }
      },
      (err) => { toast.error(err.code === err.PERMISSION_DENIED ? "Location permission was denied" : err.message); stopTracking(); },
      { enableHighAccuracy: true, maximumAge: 10_000, timeout: 30_000 },
    );
    toast.success(`Sharing this device's live location as ${v.vendor_code}. Keep this page open.`);
  }

  const all = query.data ?? [];
  const nearest = useMemo(() => myLocation ? nearestActiveVendor(all, myLocation) : null, [all, myLocation]);
  const rows = useMemo(() => {
    const filtered = filterVendorsByRadius(filterVendorDetails(all, search, canFilter ? filters : emptyVendorFilters), myLocation, canFilter ? appliedRadius : null);
    if (canFilter) return sortVendorDetails(filtered, filters.sort, myLocation);
    if (!myLocation) return filtered;
    return filtered.sort((a, b) => {
      const aDistance = hasCoordinates(a) ? distanceKm(myLocation, a) : Infinity;
      const bDistance = hasCoordinates(b) ? distanceKm(myLocation, b) : Infinity;
      return aDistance - bDistance || a.vendor_code.localeCompare(b.vendor_code);
    });
  }, [all, search, myLocation, appliedRadius, filters, canFilter]);

  function applyRadius(event: React.FormEvent) {
    event.preventDefault();
    const meters = radiusInMeters(radius, radiusUnit);
    if (meters === null) return void toast.error("Enter a distance greater than zero.");
    setAppliedRadius(meters);
    findNearby();
  }

  return <AppShell>
    <PageHeader title="Street vendors" description="Registered vendors serving customers across Maseru, each with GPS coordinates and a location name." action={isAdmin ? <Button onClick={() => { setEditing(null); setOpen(true); }}><Plus className="size-4" /> Register vendor</Button> : undefined} />
    {!isAdmin && <section className="space-y-4 border-y py-5" aria-label="Nearest vendor">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="text-lg font-semibold">Nearest vendor</h2>
        <Button variant="outline" onClick={findNearby} disabled={findingNearby}><Crosshair className="size-4" />{findingNearby ? "Finding your location…" : myLocation ? "Refresh my location" : "Find nearest vendor"}</Button>
      </div>
      <TravelModeSelector mode={travelMode} onChange={setTravelMode} />
      {locationError && <p role="alert" className="text-sm text-destructive">{locationError}</p>}
      {myLocation && <p className="text-xs text-muted-foreground">Your GPS: {myLocation.latitude.toFixed(5)}, {myLocation.longitude.toFixed(5)} · Accuracy ±{Math.round(myLocation.accuracy)} m · Captured {ago(myLocation.capturedAt)}</p>}
      {myLocation && !query.isLoading && !query.error && (nearest ? <div className="flex flex-wrap items-start justify-between gap-4" aria-live="polite">
        <div className="min-w-0 space-y-1">
          <p className="font-semibold">{nearest.vendor.vendor_name} <span className="text-sm font-normal text-muted-foreground">{nearest.vendor.vendor_code}</span></p>
          <p className="flex items-start gap-2 text-sm"><MapPin className="mt-0.5 size-4 shrink-0 text-primary" /><span className="break-words">{nearest.vendor.location || "Location name not recorded"}</span></p>
          <p className="text-sm text-muted-foreground">{nearest.vendor.telephone || "Telephone not recorded"}</p>
          <p className="text-xs text-muted-foreground">Vendor GPS updated {ago(nearest.vendor.location_updated_at)}</p>
        </div>
        <VendorTravel km={nearest.distance} mode={travelMode} />
      </div> : <p className="text-sm text-muted-foreground" role="status">No active vendors have valid GPS coordinates yet.</p>)}
    </section>}
    <div className="surface-card overflow-hidden">
      <div className="space-y-3 border-b p-4">
        <div className="flex flex-wrap items-center gap-3">
          <SearchBox value={search} onChange={setSearch} placeholder="Search vendors, businesses, locations or phone" />
          {canFilter && <Button variant="outline" aria-expanded={filtersOpen} aria-controls="vendor-filters" onClick={() => setFiltersOpen((value) => !value)}><ListFilter className="size-4" />Filters</Button>}
          {canFilter && <Button variant="ghost" size="icon" aria-label="Reset all filters" title="Reset all filters" onClick={() => { setFilters(emptyVendorFilters); setSearch(""); setAppliedRadius(null); setRadius("2"); setRadiusUnit("m"); }}><X className="size-4" /></Button>}
        </div>
        {canFilter && filtersOpen && <div id="vendor-filters" className="space-y-4 border-t pt-4">
          <VendorFilterFields value={filters} onChange={setFilters} hasOrigin={myLocation !== null} />
          {filters.from && filters.to && filters.from > filters.to && <p role="alert" className="text-sm text-destructive">The registration start date must be before the end date.</p>}
          <form onSubmit={applyRadius} className="flex flex-wrap items-center gap-2">
            <Label htmlFor="vendor-radius">Within</Label>
            <Input id="vendor-radius" type="number" inputMode="decimal" min="0.001" step="any" value={radius} onChange={(event) => setRadius(event.target.value)} className="w-24" required />
            <Select value={radiusUnit} onValueChange={(value) => { if (value === "m" || value === "km") setRadiusUnit(value); }}><SelectTrigger className="w-24" aria-label="Distance unit"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="m">Meters</SelectItem><SelectItem value="km">km</SelectItem></SelectContent></Select>
            <Button type="submit" variant="outline" disabled={findingNearby}><ListFilter className="size-4" />{findingNearby ? "Locating…" : "Filter"}</Button>
            {appliedRadius !== null && <Button type="button" variant="ghost" size="icon" aria-label="Clear distance filter" title="Clear distance filter" onClick={() => setAppliedRadius(null)}><X className="size-4" /></Button>}
          </form>
        </div>}
        {canFilter && <p role="status" className="text-xs text-muted-foreground">{rows.length} of {all.length} vendors</p>}
        {canFilter && appliedRadius !== null && <div className="space-y-1 text-sm">
          <p role="status" className="text-muted-foreground">Within {appliedRadius < 1000 ? `${appliedRadius} m` : `${appliedRadius / 1000} km`} · {findingNearby ? "Finding your location…" : myLocation ? `${rows.length} vendors · straight-line distance` : "Your location is unavailable"}</p>
          {locationError && <p role="alert" className="text-destructive">{locationError}</p>}
          {myLocation && myLocation.accuracy > appliedRadius && <p role="alert" className="text-muted-foreground">GPS accuracy is ±{Math.ceil(myLocation.accuracy)} m, wider than this filter; results may be unreliable.</p>}
        </div>}
      </div>
      {query.isLoading ? <LoadingRows /> : query.error ? <ErrorState message={errorMessage(query.error)} /> : canFilter && appliedRadius !== null && findingNearby ? <LoadingRows /> : canFilter && appliedRadius !== null && !myLocation ? <EmptyState title="Location needed" description="Distance results are unavailable until your location is detected." /> : rows.length === 0 ? <EmptyState title="No vendors found" description="No vendors match your search and filters." /> :
        <Table><TableHeader><TableRow><TableHead>Code</TableHead><TableHead>Vendor</TableHead><TableHead>Location</TableHead><TableHead>GPS</TableHead>{myLocation && <TableHead>Distance & estimated time</TableHead>}<TableHead>Telephone</TableHead><TableHead>Registered</TableHead><TableHead>Status</TableHead><TableHead /></TableRow></TableHeader>
          <TableBody>{rows.map((v) => <TableRow key={v.id}>
            <TableCell className="font-medium">{v.vendor_code}</TableCell>
            <TableCell><p>{v.vendor_name}</p><p className="text-xs text-muted-foreground">{v.business_name || "Independent"}</p>{nearest?.vendor.id === v.id && <span className="text-xs font-medium text-primary">Nearest active vendor</span>}</TableCell>
            <TableCell>{v.location || "—"}</TableCell>
            <TableCell>{v.latitude != null && v.longitude != null ? <span className="text-xs"><span className="font-mono">{v.latitude.toFixed(5)}, {v.longitude.toFixed(5)}</span><span className="block text-muted-foreground">{ago(v.location_updated_at)}{trackingId === v.id ? " · live" : ""}</span></span> : <span className="text-xs text-muted-foreground">No location</span>}</TableCell>
            {myLocation && <TableCell className="whitespace-nowrap">{hasCoordinates(v) ? <VendorTravel km={distanceKm(myLocation, v)} mode={travelMode} compact /> : "No GPS"}</TableCell>}
            <TableCell>{v.telephone || "—"}</TableCell>
            <TableCell>{shortDate(v.registration_date)}</TableCell>
            <TableCell><StatusBadge status={v.status} /></TableCell>
            <TableCell className="whitespace-nowrap"><Button variant="ghost" size="icon" title="View business and map" aria-label={`View ${v.vendor_name}`} onClick={() => setViewing(v)}><Eye className="size-4" /></Button>{isAdmin && <>
              {trackingId === v.id ? <Button variant="ghost" size="icon" title="Stop sharing live location" onClick={stopTracking}><Square className="size-4" /></Button> : <Button variant="ghost" size="icon" title="Share this device's live GPS as this vendor" onClick={() => startTracking(v)}><Radio className="size-4" /></Button>}
              <Button variant="ghost" size="icon" title="Edit vendor" onClick={() => { setEditing(v); setOpen(true); }}><Pencil className="size-4" /></Button>
            </>}</TableCell>
          </TableRow>)}</TableBody></Table>}
    </div>
    <VendorDetails vendor={viewing ? all.find((v) => v.id === viewing.id) ?? viewing : null} onClose={() => setViewing(null)} origin={myLocation} mode={travelMode} onModeChange={setTravelMode} onLocate={findNearby} locating={findingNearby} locationError={locationError} />
    {isAdmin && <VendorDialog open={open} onOpenChange={setOpen} vendor={editing} onSaved={() => client.invalidateQueries({ queryKey: ["vendors"] })} onRegistered={setViewing} />}
  </AppShell>;
}

const empty = { code: "", name: "", business: "", phone: "", location: "", lat: "", lng: "", status: "Active" as "Active" | "Inactive" };

function VendorDialog({ open, onOpenChange, vendor, onSaved, onRegistered }: { open: boolean; onOpenChange: (value: boolean) => void; vendor: Vendor | null; onSaved: () => void; onRegistered?: (v: Vendor) => void }) {
  const staff = useCurrentStaff();
  const [form, setForm] = useState(empty);
  useEffect(() => {
    if (open) setForm(vendor ? { code: vendor.vendor_code, name: vendor.vendor_name, business: vendor.business_name, phone: vendor.telephone, location: vendor.location, lat: vendor.latitude?.toString() ?? "", lng: vendor.longitude?.toString() ?? "", status: vendor.status } : empty);
  }, [open, vendor]);
  const set = (key: string, val: string) => setForm((old) => ({ ...old, [key]: val }));

  const [locating, setLocating] = useState(false);

  function useDevice() {
    if (!("geolocation" in navigator)) return void toast.error("This device does not support GPS location");
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      async (p) => {
        const lat = p.coords.latitude, lng = p.coords.longitude;
        setForm((o) => ({ ...o, lat: lat.toFixed(6), lng: lng.toFixed(6) }));
        const place = await reverseGeocode(lat, lng);
        setLocating(false);
        if (place) {
          setForm((o) => ({ ...o, location: place }));
          toast.success(`Location detected: ${place}`);
        } else {
          toast.success("Coordinates captured — type the location name if needed");
        }
      },
      (e) => { setLocating(false); toast.error(e.message); },
      { enableHighAccuracy: true, timeout: 20_000 },
    );
  }

  async function pickPoint(lat: number, lng: number, name?: string) {
    setForm((o) => ({ ...o, lat: lat.toFixed(6), lng: lng.toFixed(6), ...(name ? { location: name } : {}) }));
    if (!name) { const place = await reverseGeocode(lat, lng); if (place) setForm((o) => ({ ...o, location: place })); }
  }

  async function save() {
    if (!form.code.trim() || !form.name.trim()) return void toast.error("Vendor code and name are required");
    const hasLat = form.lat.trim() !== "", hasLng = form.lng.trim() !== "";
    if (hasLat !== hasLng) return void toast.error("Enter both latitude and longitude, or leave both empty");
    const lat = hasLat ? Number(form.lat) : null, lng = hasLng ? Number(form.lng) : null;
    if (lat != null && (!Number.isFinite(lat) || lat < -90 || lat > 90)) return void toast.error("Latitude must be between -90 and 90");
    if (lng != null && (!Number.isFinite(lng) || lng < -180 || lng > 180)) return void toast.error("Longitude must be between -180 and 180");
    const payload = { token: staff.token ?? "", vendorCode: form.code.trim().toUpperCase(), vendorName: form.name.trim(), businessName: form.business.trim(), telephone: form.phone.trim(), location: form.location.trim(), status: form.status, latitude: lat, longitude: lng };
    try {
      if (vendor) await updateVendor({ data: { ...payload, id: vendor.id } });
      else await createVendor({ data: payload });
    } catch (err) {
      return void toast.error(errorMessage(err));
    }
    if (!vendor) {
      try { const list = await fetchVendors(); const created = list.find((x) => x.vendor_code === payload.vendorCode); if (created) onRegistered?.(created); } catch { /* the list refresh will still show it */ }
    }
    toast.success(vendor ? "Vendor updated" : "Vendor registered");
    onOpenChange(false); onSaved();
  }

  return <Dialog open={open} onOpenChange={onOpenChange}><DialogContent className="max-h-[92vh] overflow-y-auto sm:max-w-2xl"><DialogHeader><DialogTitle>{vendor ? "Edit vendor" : "Register vendor"}</DialogTitle><DialogDescription>Keep identification, contact, operating and GPS details current.</DialogDescription></DialogHeader>
    <div className="grid gap-4 sm:grid-cols-2">
      <Field label="Vendor code"><Input placeholder="BV-001" value={form.code} onChange={(e) => set("code", e.target.value)} /></Field>
      <Field label="Vendor name"><Input value={form.name} onChange={(e) => set("name", e.target.value)} /></Field>
      <Field label="Business name"><Input value={form.business} onChange={(e) => set("business", e.target.value)} /></Field>
      <Field label="Telephone"><Input value={form.phone} onChange={(e) => set("phone", e.target.value)} /></Field>
      <Field label="Location"><Input value={form.location} onChange={(e) => set("location", e.target.value)} /></Field>
      <Field label="Status"><Select value={form.status} onValueChange={(v) => set("status", v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="Active">Active</SelectItem><SelectItem value="Inactive">Inactive</SelectItem></SelectContent></Select></Field>
      <Field label="Latitude"><Input inputMode="decimal" placeholder="-29.3151" value={form.lat} onChange={(e) => set("lat", e.target.value)} /></Field>
      <Field label="Longitude"><Input inputMode="decimal" placeholder="27.4869" value={form.lng} onChange={(e) => set("lng", e.target.value)} /></Field>
      <div className="space-y-2 sm:col-span-2"><Label>Find exact location</Label>
        <PlaceSearch onSelect={(p) => pickPoint(p.latitude, p.longitude, p.name)} />
        <VendorMap latitude={form.lat ? Number(form.lat) : null} longitude={form.lng ? Number(form.lng) : null} onPick={(la, ln) => pickPoint(la, ln)} label={form.business || form.name} className="h-64" />
        <p className="text-xs text-muted-foreground">Search, click the map, or drag the pin — coordinates and location name fill in automatically.</p>
      </div>
      <Field label="Latitude"><Input inputMode="decimal" placeholder="-29.3151" value={form.lat} onChange={(e) => set("lat", e.target.value)} /></Field>
      <Field label="Longitude"><Input inputMode="decimal" placeholder="27.4869" value={form.lng} onChange={(e) => set("lng", e.target.value)} /></Field>
      <div className="sm:col-span-2"><Button type="button" variant="outline" size="sm" onClick={useDevice} disabled={locating}><Crosshair className="size-4" /> {locating ? "Detecting location…" : "Use this device's GPS"}</Button><p className="mt-1 text-xs text-muted-foreground">Fills in the coordinates and the location name automatically.</p></div>
    </div>
    <DialogFooter><Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button><Button onClick={save}>Save vendor</Button></DialogFooter></DialogContent></Dialog>;
}

function Field({ label, children }: { label: string; children: React.ReactNode }) { return <div className="space-y-1.5"><Label>{label}</Label>{children}</div>; }

function VendorDetails({ vendor, onClose, origin, mode, onModeChange, onLocate, locating, locationError }: { vendor: Vendor | null; onClose: () => void; origin: Coordinates | null; mode: TravelMode; onModeChange: (mode: TravelMode) => void; onLocate: () => void; locating: boolean; locationError: string | null }) {
  const destination = vendor && hasCoordinates(vendor) ? vendor : null;
  const has = destination !== null;
  return <Dialog open={!!vendor} onOpenChange={(o) => { if (!o) onClose(); }}><DialogContent className="max-h-[92vh] overflow-y-auto sm:max-w-2xl">
    {vendor && <>
      <DialogHeader><DialogTitle className="flex items-center gap-2"><Store className="size-5 text-primary" />{vendor.business_name || vendor.vendor_name}</DialogTitle><DialogDescription>{vendor.vendor_code} · {vendor.vendor_name}</DialogDescription></DialogHeader>
      <dl className="grid gap-3 text-sm sm:grid-cols-2">
        <div><dt className="text-xs text-muted-foreground">Vendor</dt><dd className="font-medium">{vendor.vendor_name}</dd></div>
        <div><dt className="text-xs text-muted-foreground">Status</dt><dd><StatusBadge status={vendor.status} /></dd></div>
        <div><dt className="text-xs text-muted-foreground">Telephone</dt><dd className="flex items-center gap-1.5"><Phone className="size-3.5" />{vendor.telephone || "—"}</dd></div>
        <div><dt className="text-xs text-muted-foreground">Registered</dt><dd>{shortDate(vendor.registration_date)}</dd></div>
        <div className="sm:col-span-2"><dt className="text-xs text-muted-foreground">Location</dt><dd className="flex items-start gap-1.5"><MapPin className="mt-0.5 size-3.5 shrink-0 text-primary" />{vendor.location || "—"}</dd></div>
        <div className="sm:col-span-2"><dt className="text-xs text-muted-foreground">Coordinates</dt><dd className="font-mono text-xs">{has ? `${destination?.latitude.toFixed(6)}, ${destination?.longitude.toFixed(6)}` : "Not recorded"}</dd></div>
      </dl>
      {has ? <>
        <div className="space-y-3 border-y py-4">
          <div className="flex flex-wrap items-center justify-between gap-2"><h3 className="font-semibold">Travel to this vendor</h3><Button size="sm" variant="outline" onClick={onLocate} disabled={locating}><Crosshair />{locating ? "Finding your location…" : origin ? "Refresh my location" : "Use my location"}</Button></div>
          <TravelModeSelector mode={mode} onChange={onModeChange} />
          {locationError && <p role="alert" className="text-sm text-destructive">{locationError}</p>}
          {origin && destination ? <VendorTravel km={distanceKm(origin, destination)} mode={mode} /> : <p className="text-sm text-muted-foreground">Your location is needed to calculate distance and estimated travel time.</p>}
        </div>
        <VendorMap latitude={vendor.latitude} longitude={vendor.longitude} label={vendor.business_name || vendor.vendor_name} className="h-72" />
        <a className="text-sm font-medium text-primary underline-offset-4 hover:underline" href={`https://www.openstreetmap.org/?mlat=${vendor.latitude}&mlon=${vendor.longitude}#map=18/${vendor.latitude}/${vendor.longitude}`} target="_blank" rel="noreferrer">Open in full map ↗</a>
      </> : <p className="text-sm text-muted-foreground">No map yet — edit this vendor and pick a location.</p>}
    </>}
  </DialogContent></Dialog>;
}
