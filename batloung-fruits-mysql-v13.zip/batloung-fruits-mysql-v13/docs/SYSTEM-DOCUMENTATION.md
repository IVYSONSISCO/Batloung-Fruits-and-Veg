# Batloung Fruits Distribution Management System

## 1. System overview

The system records fruit products by box size, suppliers and purchases, Maseru street vendors, vendor orders, stock movements, and operational reports. Staff authenticate before accessing management pages. Administrators maintain the supply catalogue, purchases and vendors, and approve orders; Sales staff create and cancel their own orders.

## 2. Roles

| Role | Access |
|---|---|
| Administrator | Dashboard, fruits, box sizes, products, suppliers, purchases, vendors, orders (all staff), reports |
| Sales | Dashboard and Orders only. Sees and creates only their own orders and may only cancel them. Cannot approve or progress orders, and cannot register or edit vendors or catalogue data. All of this is enforced by the server, not just hidden in the interface. |

The first six registered users become Administrators. Later users receive the Sales role.

## 3. Data model

```text
profiles 1──< user_roles
     │
     └──< sessions

fruits 1──< products >──1 box_sizes
                   │
suppliers 1──< purchases
                   │
                   └── increases products.stock_quantity

street_vendors 1──< orders 1──< order_items >──1 products
                               │
                               └── calculates orders.total_amount
```

## 4. Business rules

- Each fruit and box-size combination represents one product.
- Purchases contain supplier, product, South African province, quantity, cost price, date, and notes.
- Recording a purchase increases the selected product's box stock.
- Orders may only use active products and active registered vendors.
- Ordered quantity cannot exceed current stock.
- The database supplies the product selling price and calculates line/order totals.
- Status flow is `Pending → Confirmed → Processing → Ready → Completed`.
- An open order may be cancelled. Completed or cancelled orders are terminal.
- Completing an order deducts stock exactly once.
- Only an Administrator can approve or progress an order (Confirmed, Processing, Ready, Completed). Sales staff may only cancel.
- Sales staff can only view, create and cancel orders they created themselves; Administrators see every order. The dashboard and reports show Sales staff figures for their own orders only.
- Only an Administrator can register or edit street vendors.
- Prices and totals are displayed in Lesotho Maloti (M/LSL).

## 5. Application pages

- **Dashboard:** headline totals, sales, stock health, and order pipeline.
- **Fruits & Products:** searchable catalogue, box sizes, prices, stock, availability, add/edit actions.
- **Suppliers:** supplier directory with province and contact details.
- **Purchases:** incoming stock history and stock-receipt form.
- **Street Vendors:** registration, contact details, location name, active status and GPS coordinates. Administrators can search a place, click or drag a pin on a free OpenStreetMap map, type coordinates, press Use this device's GPS (which also fills in the place name), or share the device's live position as a vendor (saved every 15 seconds). Sales staff can view vendors (read only) and press Find nearest vendor (available to every signed-in user) to see the closest active vendor and straight-line distances from their own device GPS. Distances are straight-line (shown in meters and kilometers) with a rough walking (5 km/h) or driving (30 km/h) time estimate; they ignore roads and traffic. Every user can press the eye button on a vendor to see its business details and a map of its position.
- **Orders:** list, create order with multiple lines, detail view, totals, cancellation, and status progression (Administrators). Each order has a printable receipt and a downloadable PDF receipt showing vendor details, order details, line items, box and unit totals, and notes.
- **Reports:** date-filtered sales and purchasing totals, inventory and vendor totals, monthly sales and status charts.

## 6. Data access notes

The browser never talks to MySQL. Every action is a server function that runs only on the server, where the MySQL credentials live in environment variables. Staff sign in with an email and password; passwords are stored as bcrypt hashes and each sign-in creates a session token held in the `sessions` table. Every server function checks the session token and the staff member's role (Administrator or Sales) before it reads or changes data, so the rules above hold even if someone bypasses the interface. Stock changes, order totals and status transitions run inside MySQL transactions so a failed step cannot leave stock or totals half-updated.

## 7. Test checklist

1. Create accounts one through six and confirm each receives Administrator access.
2. Create the seventh account and confirm it receives Sales access: only Dashboard, Orders and Street vendors appear in the sidebar.
3. Add a fruit and product; confirm it appears in catalogue search.
4. Add a supplier for each required province sample.
5. Record a purchase and confirm product stock increases by the exact box quantity.
6. Register and edit a vendor; confirm inactive vendors cannot receive new orders.
7. Create an order with multiple products; verify prices and total.
8. Attempt an order quantity above stock and confirm it is rejected.
9. Progress an order through every valid status; confirm invalid skips are rejected.
10. Complete an order and confirm stock decreases once only.
11. Cancel an open order and confirm it cannot be reopened.
12. Filter reports by date and verify totals against order and purchase records.
13. Check all pages on desktop and mobile widths.
14. Sign out and confirm protected pages return to staff access.
15. As a Sales user, create an order and confirm it appears; confirm the order list shows only orders you created.
16. As a Sales user, open your order and confirm there is no Move to button, only Cancel order, and the message that only an administrator can approve it.
17. As an Administrator, confirm you can see the Sales user's order and progress it to Completed.
18. As a Sales user, confirm Dashboard, Orders and Street vendors appear in the sidebar, and that the Street vendors page has no Register, Edit or share actions.
19. Open any order and use Download PDF; confirm the receipt contains vendor details, order details, line items, totals and notes.
20. As an Administrator, edit a vendor, press Use this device's GPS, and confirm the coordinates and a place name are filled in; save and confirm the GPS column shows the coordinates.
21. As an Administrator, press the share button on a vendor and confirm the coordinates update every 15 seconds; press stop sharing.
22. Register a vendor by searching a place or clicking the map; confirm coordinates and location name fill in, and that the business details and map open after saving. Open the eye button on any vendor to see the map.
23. As any user, switch between Walking and Driving, press Find nearest vendor, allow location, and confirm the closest active vendor, its location name, telephone and distance appear, and the table shows a distance column sorted nearest first.

## 8. Demonstration script

1. Sign in as Administrator and introduce the dashboard figures.
2. Open Fruits & Products and show fruit, box size, selling price, and live stock.
3. Open Suppliers, then record a purchase and show the stock increase.
4. Register a Maseru street vendor.
5. Create a multi-line order for that vendor and show its calculated total.
6. Progress the order from Pending to Completed and show the stock reduction.
7. Open Reports, set a date range, and explain sales, cost, inventory, and order-status charts.
8. Open Street vendors, show a vendor's GPS coordinates and location name.
9. Sign out, then sign in as Sales to demonstrate role-aware navigation: only Dashboard, Orders and Street vendors (read only, with Find nearest vendor), only their own orders, cancel but not approve.
10. Open an order and use Download PDF to show the receipt.